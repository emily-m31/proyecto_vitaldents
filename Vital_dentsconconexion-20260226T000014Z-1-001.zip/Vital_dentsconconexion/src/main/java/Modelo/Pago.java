/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Pago {
    private int id_Pago;
    private String monto;
    private int Medio_pago_id_Mediodepago;
    private int Estado_pago_id_Estadopago;
    private int Cita_id_Cita;
    
    public int getid_Pago() {
       return id_Pago;
    }
    
    public void setid_Pago(int id_Pago){
        this.id_Pago = id_Pago;
             
    }
    public String getmonto() {
       return monto;
    }
    
    public void setmonto(String monto){
        this.monto = monto;
             
    }
     public int Estado_pago_id_Estadopago() {
       return Estado_pago_id_Estadopago;
    }
    
    public void setEstado_pago_id_Estadopago(int Estado_pago_id_Estadopago){
        this.Estado_pago_id_Estadopago = Estado_pago_id_Estadopago;
             
    } public int getMedio_pago_id_Mediodepago() {
       return Medio_pago_id_Mediodepago;
    }
    
    public void setMedio_pago_id_Mediodepago(int setMedio_pago_id_Mediodepago){
        this.Medio_pago_id_Mediodepago = setMedio_pago_id_Mediodepago;
             
    } public int Cita_id_Cita() {
       return Cita_id_Cita;
    }
    
    public void setCita_id_Cita(int Cita_id_Cita){
        this.Cita_id_Cita = Cita_id_Cita;
             
    }
    
}
