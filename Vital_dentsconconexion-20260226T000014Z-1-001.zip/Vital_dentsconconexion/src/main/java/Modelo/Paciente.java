/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Paciente {
    private int id_Paciente;
    private String nombrepaciente;
    private String documento;
    private String telefono;
    private String correo;
    private int Tipo_documento_id_Tipodocumento;
    
    public int getid_Paciente() {
       return id_Paciente;
    }
    
    public void setid_Paciente(int id_Paciente){
        this.id_Paciente = id_Paciente;
             
    }

    public String getnombrepaceinte(){
        return nombrepaciente;
    }
    
    public void setnombrepaciente (String nombrepaciente){
        this.nombrepaciente = nombrepaciente;
    }
    
    
    public String getndocumento(){
        return documento;
    }
    
    public void setdocumento (String documento){
        this.documento = documento;
    }
    
    
    public String gettelefono(){
        return telefono;
    }
    
    public void settelefono (String telefono){
        this.telefono= telefono;
    }
    
    
    public String getcorreo(){
        return nombrepaciente;
    }
    
    public void setcorreo (String correo){
        this.correo = correo;
    }
    
    
    public int Tipo_documento_id_Tipodocumento(){
        return Tipo_documento_id_Tipodocumento;
    }
    
    public void setTipo_documento_id_Tipodocumento(int Tipo_documento_id_Tipodocumento){
        this.Tipo_documento_id_Tipodocumento = Tipo_documento_id_Tipodocumento;
    }
    
}
