/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Cita {
     private int id_Cita;
    private String fecha_hora;
    private String descripcion_cita;
    private int Paciente_id_paciente;
    private int Usuario_id_Usuario;
    private int Estado_cita_id_cita;
    private int Tipo_Tratamiento_id_Tipotratam;
    
    public int getid_Cita() {
       return id_Cita;
    }
    
    public void setid_Cita(int id_Cita){
        this.id_Cita = id_Cita;
             
    }

    public String getfecha_hora(){
        return fecha_hora;
    }
    
    public void setfecha_hora(String fecha_hora){
        this.fecha_hora = fecha_hora;
    }
    
    public String getdescripcion_cita() {
       return descripcion_cita;
    }
    
    public void setdescripcion_cita(String descripcion_cita){
        this.descripcion_cita = descripcion_cita;
             
    }

    public int getPaciente_id_paciente(){
        return Paciente_id_paciente;
    }
    
    public void setPaciente_id_paciente(int Paciente_id_paciente){
        this.Paciente_id_paciente = Paciente_id_paciente;
    }
    
     public int Usuario_id_Usuario(){
        return Usuario_id_Usuario;
    }
    
    public void Usuario_id_Usuario(int Usuario_id_Usuario){
        this.Usuario_id_Usuario = Usuario_id_Usuario;
    }
    
     public int getEstado_cita_id_cita(){
        return Estado_cita_id_cita;
    }
    
    public void setEstado_cita_id_cita(int Estado_cita_id_cita){
        this.Estado_cita_id_cita = Estado_cita_id_cita;
    }
    
     public int getTipo_Tratamiento_id_Tipotratam(){
        return Tipo_Tratamiento_id_Tipotratam;
    }
    
    public void setTipo_Tratamiento_id_Tipotratam(int Tipo_Tratamiento_id_Tipotratam){
        this.Tipo_Tratamiento_id_Tipotratam = Tipo_Tratamiento_id_Tipotratam;
    }
    
}
