/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Estado_cita {
    private int id_Estadocita;
    private String descripcion_estadoci;

    
    public int getid_Estadocita() {
       return id_Estadocita;
    }
    
    public void setid_Estadocita(int id_Estadocita){
        this.id_Estadocita = id_Estadocita;
             
    }

    public String getdescripcion_estadoci(){
        return descripcion_estadoci;
    }
    
    public void descripcion_estadoci (String descripcion_estadoci){
        this.descripcion_estadoci = descripcion_estadoci;
    } 
}
