/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Medio_pago {
    private int id_Mediodepago;
    private String descripcion_mediopa;
 
    
    public int getid_Mediodepago() {
       return id_Mediodepago;
    }
    
    public void setid_Mediodepago(int id_Mediodepago){
        this.id_Mediodepago = id_Mediodepago;
             
    }

    public String getdescripcion_mediopa(){
        return descripcion_mediopa;
    }
    
    public void setdescripcion_mediopa (String descripcion_mediopa){
        this.descripcion_mediopa = descripcion_mediopa;
    }
    
}
