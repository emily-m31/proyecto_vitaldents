/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Tipo_tratamiento {
    
    private int id_Tipotratam;
    private String descripcion_estadoci;
    private String costo;
    
    public int getid_Tipotratam() {
       return id_Tipotratam;
    }
    
    public void setid_Tipotratam(int id_Tipotratam){
        this.id_Tipotratam = id_Tipotratam;
             
    }
    public String getdescripcion_estadoci() {
       return descripcion_estadoci;
    }
    
    public void setdescripcion_estadoci(String descripcion_estadoci){
        this.descripcion_estadoci = descripcion_estadoci;
             
    }
    
     public String costo() {
       return costo;
    }
    
    public void setcosto(String costo){
        this.costo = costo;
    }
}

