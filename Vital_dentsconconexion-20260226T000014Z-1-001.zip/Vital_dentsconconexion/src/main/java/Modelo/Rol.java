/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Rol {
    private int id_Rol;
    private String descripcion_rol;
   
    
    public int getid_Rol() {
       return id_Rol;
    }
    
    public void setid_Rol(int id_Rol){
        this.id_Rol = id_Rol;
             
    }
    public String getdescripcion_rol() {
       return descripcion_rol;
    }
    
    public void setdescripcion_rol(String descripcion_rol){
        this.descripcion_rol = descripcion_rol;
             
    }
}
