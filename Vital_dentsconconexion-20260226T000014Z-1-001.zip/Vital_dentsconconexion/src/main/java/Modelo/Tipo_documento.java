/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Tipo_documento {
    private int id_Tipodocumento;
    private String descripcion_tipodoc;
    
    public int getid_Tipodocumento() {
       return id_Tipodocumento;
    }
    
    public void setid_Tipodocumento(int id_Tipodocumento){
        this.id_Tipodocumento = id_Tipodocumento;
             
    }
    public String getdescripcion_tipodoc() {
       return descripcion_tipodoc;
    }
    
    public void setdescripcion_tipodoc(String descripcion_tipodoc){
        this.descripcion_tipodoc = descripcion_tipodoc;
             
    }
}
