/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Usuarios {
    
    private int id_Usuario;
    private String nombreus;
    private String contraseña;
    private String correousuario;
    private int Rol_id_rol;
    
    public int getid_Usuario() {
       return id_Usuario;
    }
    
    public void setid_Usuario(int id_Usuario){
        this.id_Usuario = id_Usuario;
             
    }

    public String getnombreus(){
        return nombreus;
    }
    
    public void setnombreus (String nombreus){
        this.nombreus = nombreus;
    }
    
     public String contraseña(){
        return contraseña;
    }
     
    public void setcontraeña (String contraseña){
        this.contraseña = contraseña;
    }
    
    public String correousuario(){
        return correousuario;
    }
    
     public void correousuario (String correousuario){
        this.correousuario = correousuario;
    }
     
    public int getRol_idrol(){
        return Rol_id_rol;
    }
    
     public void setRol_id_rol (int Rol_id_rol){
        this.Rol_id_rol = Rol_id_rol;
    }
     
}

