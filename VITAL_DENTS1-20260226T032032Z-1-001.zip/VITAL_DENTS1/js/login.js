document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let usuario = document.getElementById("usuario").value;
    let password = document.getElementById("password").value;

    if (usuario === "" || password === "") {
        alert("Por favor complete todos los campos");
    } else {
        alert("Login enviado (solo frontend por ahora)");
    }
});
